"""
Helper functions for indicator scoring, threat mapping, and normalization.
"""

def get_confidence_score(pulse_name):
    """
    Assign confidence scores based on pulse type.
    Higher scores for more reliable/severe threat types.
    """
    confidence_map = {
        "ssh_bruteforce": 95,      # High confidence - active attacks
        "tcp_portscan": 85,        # High confidence - reconnaissance
        "telnet_honeypot": 90,     # Very high - IoT attacks
    }
    return confidence_map.get(pulse_name, 75)


def get_threat_type(pulse_name):
    """
    Map pulse names to human-readable threat types.
    """
    threat_map = {
        "tcp_portscan": "Port Scanning",
        "ssh_bruteforce": "SSH Brute Force",
        "telnet_honeypot": "IoT/Telnet Attack"
    }
    return threat_map.get(pulse_name, "Unknown")